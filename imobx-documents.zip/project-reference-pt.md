# Quem está preparando a IMOBX, e de onde vêm as informações?

**Versão 0.9, 9 de novembro de 2026**

## Quem faz o quê, e quais funções ainda estão vagas?

| Pessoa ou grupo | Papel no plano | Situação |
| --- | --- | --- |
| Rafael Britto | Fundador; construtor no Rio de Janeiro. Obra, orçamento e contatos locais. | Funções ainda não definidas por escrito. |
| John | Comunicação, documentação e coordenação das ferramentas digitais. | Ajuda a preparar o projeto. Não pode gastar nem assinar pela IMOBX. |
| IMOBX | Organização do projeto, contratos e acompanhamento das contas. | A forma jurídica e os representantes legais estão em definição. |
| OLYMPUS | Construtora proposta, ligada a Rafael; nenhum contrato assinado. | Só é contratada depois de combinar o serviço, comparar preços e ter a aprovação de alguém independente da construtora. |
| Moradores | Condições de moradia e participação nos assuntos comuns. | Regras e representantes a combinar com os moradores. |
| Parceiro comunitário ou beneficente | Acesso a imóvel, famílias ou financiadores, se a parceria for acordada. | Em conversa; nada acordado. |
| Assessoria jurídica e contabilidade | Orientação sobre contratos e contas. | Os próprios advogados e a contadora de Rafael; o papel deles na IMOBX ainda será combinado. |
| Conferência da obra | Conferência independente da segurança e da obra entregue. | Vaga: estamos procurando essa pessoa. |
| Financiadores e divulgadores | Recursos ou trabalho conforme acordos próprios. | Recebem só os direitos do próprio acordo. Quem recebe para divulgar a IMOBX precisa avisar. |

Como a construtora proposta tem ligação com um fundador, outras pessoas comparam os preços, aprovam o contrato e conferem o serviço.

## Nossas fontes

Fontes das pesquisas e dos números.

[O orçamento de Rafael e o relato dele sobre os lofts](https://imobx.org/whitepaper.html#3-the-cost-proposal-already-supplied)

Números do próprio Rafael, de 30/11/2025 e 20/01/2026.

[IBGE: Censo 2022, favelas e comunidades urbanas](https://agenciadenoticias.ibge.gov.br/agencia-noticias/2012-agencia-de-noticias/noticias/41797-censo-2022-brasil-tinha-16-4-milhoes-de-pessoas-morando-em-favelas-e-comunidades-urbanas)

16,4 milhões de pessoas, 8,1% da população, no Censo 2022.

[CAIXA: SINAPI](https://www.caixa.gov.br/poder-publico/modernizacao-gestao/sinapi/paginas/default.aspx)

A tabela brasileira de referência de custos de obra, usada no orçamento de Rafael.

[CVM: Parecer de Orientação 40](https://conteudo.cvm.gov.br/legislacao/pareceres-orientacao/pare040.html)

Como a CVM avalia um criptoativo: pelos direitos que ele dá, não pelo nome.

[Lei 13.019: definição para parcerias com o poder público](https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2014/lei/l13019compilado.htm)

O artigo 2º define organizações sem fins lucrativos para essa lei.

[Arc: documentação oficial](https://docs.arc.io/)

A descrição da própria Arc sobre a rede e as ferramentas de pagamento.

[Fundação João Pinheiro: déficit habitacional de 2024](https://fjp.mg.gov.br/deficit-habitacional-recua-34-no-brasil-e-soma-5-773-983-domicilios/)

Cerca de 5,77 milhões de domicílios estão no déficit habitacional de 2024 pelo critério da FJP, que também conta famílias que gastam parte excessiva da renda com aluguel.
