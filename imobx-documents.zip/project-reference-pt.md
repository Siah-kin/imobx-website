# Quem está preparando a IMOBX, e de onde vêm as informações?

**Versão 0.9, 9 de novembro de 2026**

## Quem faz o quê, e quais funções ainda estão vagas?

| Pessoa ou grupo | Papel no plano | Situação |
| --- | --- | --- |
| Rafael | Cofundador; construtor no Rio de Janeiro. Obra, orçamento e contatos locais. | Funções ainda não definidas por escrito. |
| John | Cofundador; comunicação, documentação e coordenação das ferramentas digitais. | Ajuda a preparar o projeto. Não pode gastar nem assinar pela IMOBX. |
| IMOBX | Organização do projeto, contratos e acompanhamento das contas. | Será uma cooperativa habitacional, ainda não registrada. Os representantes legais estão em definição. |
| OLYMPUS | Construtora proposta, ligada a Rafael; nenhum contrato assinado. | Só é contratada depois de combinar o serviço, comparar preços e ter a aprovação de alguém independente da construtora. |
| Moradores | Condições de moradia e participação nos assuntos comuns. | Regras e representantes a combinar com os moradores. |
| Parceiro comunitário ou beneficente | Acesso a imóvel, famílias ou financiadores, se a parceria for acordada. | Em conversa; nada acordado. |
| Assessoria jurídica e contabilidade | Orientação sobre contratos e contas. | Os próprios advogados e a contadora de Rafael; o papel deles na IMOBX ainda será combinado. |
| Conferência da obra | Conferência independente da segurança e da obra entregue. | Vaga: estamos procurando essa pessoa. |
| Financiadores e divulgadores | Recursos ou trabalho conforme acordos próprios. | Recebem só os direitos do próprio acordo. Quem recebe para divulgar a IMOBX precisa avisar. |

Como a construtora proposta tem ligação com um fundador, outras pessoas comparam os preços, aprovam o contrato e conferem o serviço.

## Nossas fontes

Fontes das pesquisas e dos números.

[O orçamento de Rafael e o relato dele sobre os lofts](https://imobx.org/whitepaper.html#3-the-cost-proposal-already-supplied)

Números do próprio Rafael: o orçamento de 30/11/2025 e 20/01/2026 e as respostas de 4 a 6 de novembro de 2026, com o CUB-RJ de setembro de 2026 (Sinduscon-Rio).

[IBGE: Censo 2022, favelas e comunidades urbanas](https://agenciadenoticias.ibge.gov.br/agencia-noticias/2012-agencia-de-noticias/noticias/41797-censo-2022-brasil-tinha-16-4-milhoes-de-pessoas-morando-em-favelas-e-comunidades-urbanas)

16,4 milhões de pessoas, 8,1% da população, no Censo 2022.

[CAIXA: SINAPI](https://www.caixa.gov.br/poder-publico/modernizacao-gestao/sinapi/paginas/default.aspx)

A tabela brasileira de custos de obra item a item, para conferir o orçamento por item que o Rafael está preparando.

[CVM: Parecer de Orientação 40](https://conteudo.cvm.gov.br/legislacao/pareceres-orientacao/pare040.html)

Como a CVM avalia um criptoativo: pelos direitos que ele dá, não pelo nome.

[Lei 13.019: definição para parcerias com o poder público](https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2014/lei/l13019compilado.htm)

O artigo 2º define organizações sem fins lucrativos para essa lei.

[Arc: documentação oficial](https://docs.arc.io/)

A descrição da própria Arc sobre a rede e as ferramentas de pagamento.

[Fundação João Pinheiro: déficit habitacional de 2024](https://fjp.mg.gov.br/deficit-habitacional-recua-34-no-brasil-e-soma-5-773-983-domicilios/)

A medida de déficit habitacional da FJP também conta famílias que gastam parte excessiva da renda com aluguel.

[Índice FipeZAP, via Diário do Comércio](https://diariodocomercio.com.br/economia/aluguel-sobe-dobro-inflacao-2026/)

O índice acompanha preços anunciados em imóveis prontos, então os aumentos em contratos já existentes ficam de fora.

[IBGE, Censo 2022, via Agência Pública](https://apublica.org/2023/06/censo-2022-brasil-tem-11-milhoes-de-casas-e-apartamentos-vagos/)

O Censo de 2022 contou cerca de 11,4 milhões de casas e apartamentos vazios, mas um imóvel vazio nem sempre está onde a família precisa, nem em condições de morar.

[Agência Brasil, 9 de dezembro de 2025 (lido no O Povo)](https://www.opovo.com.br/noticias/economia/2025/12/09/caixa-libera-contratacao-de-mais-de-um-financiamento-imobiliario.html)

Um exemplo da Caixa: o banco financia até 80% do valor do imóvel no sistema SAC e até 70% na Tabela Price. O prazo chega a 420 meses, ou 35 anos. Pela nossa conta, o resto do preço, de 20 a 30%, é a entrada.

[Índice de inadimplência de aluguel da Superlógica, via Diário do Rio](https://diariodorio.com/economia/mercado-imobiliario/2026/08/29/inadimplencia-de-aluguel-no-rio-melhora-em-2026-e-atinge-minima-historica.html)

No estado do Rio, 3,68% dos aluguéis acompanhados pelo índice tinham mais de 60 dias de atraso em julho de 2026. O índice cobre contratos administrados com o software da Superlógica, não todos os aluguéis do estado.
