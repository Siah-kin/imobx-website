# IMOBX

A documented rent-to-own housing model for Rio

**Partner discussion draft · Version 0.7, 21 October 2026**



## 1. Families would rent toward owning their home

IMOBX is preparing a first rent-to-own housing project in Rio.



- Local construction and clear family agreements.

- Residents help shape shared spaces and decisions.

- Current stage: planning, documents and design.



Source: [IMOBX project reference](reference.html). Lists what exists and what is not decided, with a review date. It is the project's own record.

**Presenter notes:** Rafael brings construction and local experience; John handles community and digital work. Their roles, the legal organization and the right to use each property need written agreements. This draft explains the plan and asks for partners; it does not offer an investment.



## 2. Start with what a family needs

The first project would help displaced families and people unable to use ordinary housing finance.



- Agree who can join and what payments are affordable.

- Explain repairs, payments and the path to buying the home.

- Make help and complaints easy to access.



Source: [UN-Habitat: adequate housing](https://unhabitat.org/11-1-adequate-housing). Describes what adequate housing means. It does not assess IMOBX.

**Presenter notes:** Brazil’s 2022 Census counted about 16.4 million residents in favelas and urban communities, 8.1% of the population. That is national context, not a description of a selected family or site. Living in a favela does not itself mean being displaced. Listen to families about work, schools, transport, support networks and whether a move suits them. Participating households are not identified in this draft.



## 3. Rafael has supplied a building budget

His US$27,777 per-home plan uses CUB and SINAPI, Brazilian building-cost references.



- Land US$5,550 · construction US$18,600 · solar US$1,500.

- Shared works US$1,500 · design and legal work US$627.

- The village plan assumes at least 36 homes built together.



Source: [Whitepaper, section 3: the costs](whitepaper.html#3-the-cost-proposal-already-supplied). Shows how Rafael supplied these figures. It is not an independent check of them.

**Presenter notes:** On 30 November 2025 Rafael showed a US$21,883.86 construction calculation plus land, then the revised US$27,777 budget. Direct purchasing and shared costs form part of the plan. Thirty-six homes total US$999,972, with a proposed 12-month program. These are Rafael’s budget figures, not an index-published finished-home price. Track dates, included work, prices in reais and actual invoices. The separate January contract is US$27,777 for both lofts together.



## 4. Part of each payment would go towards buying the home

The household could see what it has paid towards the purchase and how much remains.



- The agreement sets the price and how much of each payment goes towards buying.

- The household can follow the amount paid and the remaining price.

- The whole home transfers to the household once the purchase terms are met.



**Presenter notes:** The first homes are still being planned. This slide does not offer a home. The first home’s price, monthly payment and time to pay have not been set. How much of each payment would count towards buying it also remains to be agreed. Rafael’s village budget and the two-loft contract are construction cases, not household sale prices. Repair charges, hardship and exit terms remain open. The household explanation is at rent-to-own.html. Before building, the project needs documents showing the right to use the property, a budget and someone independent to inspect the work.



## 5. Show where each payment goes

Keep rent, donations, grants, service income and trading fees separately identified.



- Pay taxes, repairs and agreed running costs.

- Keep money for empty homes and promises made to families.

- Fund more homes; consider any permitted investor payments afterward.



**Presenter notes:** Money credited toward a family’s purchase is not a second receipt of cash. Money paid by a buyer to a token seller normally goes to that seller, apart from separately collected fees. Money locked in a trading market is not also available to build homes.



## 6. Pay today’s bills and plan the next homes

Running the existing homes and building more need separate budgets.



- Check the budget with little or no trading income.

- Rent ends when the family becomes the home’s owner.

- Show how continuing income and new building funds will be found.



**Presenter notes:** Having a thousand homes does not itself show that the accounts balance. One-off grants can help construction but do not become continuing income. Any ongoing charge needs a real, affordable service under agreed terms.



## 7. Residents would decide how shared spaces are used

Courtyard use, study-room hours, repair priorities and representatives are resident matters.



- One vote per member is an option under discussion.

- No investment purchase or promotional work would be required for a voice.

- Investor rights and each household’s contract have their own terms.



Source: [ICA: cooperative identity](https://ica.coop/en/cooperatives/cooperative-identity). States the principles of cooperatives, including member participation. It does not review IMOBX.

Source: [Elinor Ostrom: Nobel lecture](https://www.nobelprize.org/prizes/economic-sciences/2009/ostrom/lecture/). Is research on how communities manage shared resources. It does not test IMOBX's rules.

**Presenter notes:** The voting procedure, spending limits and way to question a decision have not been agreed with participants. In the proposed repair process, a resident reports a leak, a maintenance contact obtains a quote, spending follows the agreed limit and another person checks the work. Buying tokens would not give control over another household’s contracted purchase price. See rent-to-own.html#decisions and roadmap.html#governance. Resident decision-making is still a proposal and has not yet been demonstrated in IMOBX.



## 8. From a request to checked work

Agreed roles, spending limits and shared records keep everyday work moving.



- A resident raises an issue; a responsible person takes it forward.

- Someone else checks the work, payment and receipt.

- Open tasks and approvals are ready for whoever takes over.



**Presenter notes:** Before the pilot, residents and the organization need to agree which matters each group decides, spending limits and how a decision can be reviewed. For example: a resident reports a leak, the maintenance role assesses it and obtains a quote, spending follows the agreed rule, and another person checks the repair and payment. Routine work should proceed within those limits without constant founder instructions. Residents need ways to choose and replace responsible people. The support channel would show requests, decisions and progress; software assistants could organize documents and reminders. Blockchain could show payment amounts and destinations. These tools follow the rules agreed by participants. The complete process still needs to be demonstrated in IMOBX.



## 9. A possible token could fund operations and outreach

Buyers of new tokens would pay the organisation that creates and sells them. Their rights are still undecided.



- A later resale normally pays the seller; any project fee is separate.

- Paid outreach needs a funded task, a check of the completed work and disclosure of payment.

- No dividend, discount or token voting model has been selected.



Source: [CVM Guidance Opinion 40](https://conteudo.cvm.gov.br/legislacao/pareceres-orientacao/pare040.html). Says Brazil's regulator looks at what an investment actually gives, not its name. It does not say whether an IMOBX token would comply.

Source: [IMOBX: questions about funding, tokens and governance](https://siah-kin.github.io/imobx-website/transparency.html#funding-questions). Holds the project's own answers on the token. Nothing there is decided.

**Presenter notes:** Four scenarios remain: no IMOBX token, a service or membership benefit, a share of collected fees, or an investment in the operation. These are alternatives, not combined promised rights. Capital for construction, outreach payments and investor income have different budgets and commitments. Residents’ participation would not depend on investment or promotion. Reference.html#token compares what a buyer might receive and the decisions still open.



## 10. Each stage needs evidence before it advances

The roadmap names proposed roles and conditions for proceeding.



- Property rights, household terms and budgets underpin the first homes.

- Digital payment trials and token research can progress alongside them.

- Expansion follows operating results and funding for existing commitments.



Source: [IMOBX project stages](https://siah-kin.github.io/imobx-website/roadmap.html). Sets out the stages and what must be ready in each. It sets no dates.

**Presenter notes:** The six stages are legal structure and property; resident participation; first homes; payment records people can check; funding and account review; more homes and owner partnerships. Rafael contributes construction and local knowledge; John contributes communication and digital coordination. Adviser, accounting, approval and independent inspection roles still need appointments. OLYMPUS is a possible builder connected to Rafael. Its appointment would need approval by someone independent of the builder. A community or charitable partner is a possible relationship. Construction dates depend on the chosen project, funding and permissions. A review after at least three operating months is proposed before expanding. The roadmap lists responsibilities and reasons to pause each stage.



## 11. Measure homes and promises kept

Follow actual costs, accounts and families’ experience.



- Check completed work, final cost and delays.

- Check money received and paid against the records; report repairs and unresolved issues.

- Show participation and progress toward owning the home.



**Presenter notes:** Agree response times and affordability targets with local participants. Report homes as planned, contracted, delivered or transferred, with checked records. Token prices and holder counts do not measure how well families are housed. The published records do not yet document completed home transfers or committed capital.



## 12. One property can become a project to assess

An owner, building team, local organization and funder could develop a costed proposal together.



- Owners: property, condition and donation, sale or lease terms.

- Builders and funders: costed work, funding purpose and commitments.

- Households: affordable terms, location, repairs and resident decisions.



**Presenter notes:** These are possible contributions, not confirmed partnerships or contracts. The contact page has separate routes and explanations. There is no contact address yet: visitors can prepare and copy an introduction, but the website sends nothing. A property introduction can lead to assessment, not an automatic transfer. If a builder is connected to an IMOBX founder, someone independent must check the contract and completed work. See contact.html and rent-to-own.html#property.


