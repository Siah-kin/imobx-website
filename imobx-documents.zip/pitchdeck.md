# IMOBX

A documented rent-to-own housing model for Rio

**Partner discussion draft · v0.2 · 15 October 2026**



## 1. A home. An agreement. A record of the money.

IMOBX is preparing a Rio housing pilot with a written rent-to-own pathway and project reporting.



- Ground work: construction, property access and resident operations.

- Digital work: clear information, questions and approved reports.

- Current stage: design and evidence review.



**Presenter notes:** Introduce Rafael's proposed construction/local role and John's proposed community/digital role. Their agreements, the legal entity and pilot property control still need documentary confirmation. This deck is for partners, not an investment solicitation.



## 2. Start with households and the home.

The intended pilot serves households displaced or excluded from ordinary housing finance.



- Define eligibility and affordability with local participants.

- Explain payments, maintenance and the ownership path in ordinary Portuguese.

- Provide a support and dispute route residents can actually use.



**Presenter notes:** Brazil’s 2022 Census recorded around 16.4 million residents in favelas and urban communities, 8.1% of the population. IBGE describes community formation and identities, while UN-Habitat provides the wider inadequate-housing context. These are national/global references, not evidence of the selected pilot site. Do not describe all informal-settlement residents as displaced. Listen to households about location, work, services and their preferences. The founders’ target group requires local definition and consultation. No pilot residents are claimed as enrolled.



## 3. A reference-based budget. A delivery plan to track.

Rafael’s $27,777 per-home budget uses CUB/SINAPI references and cost engineering.



- Land $5,550 · construction $18,600 · solar $1,500.

- Shared infrastructure $1,500 · legal/design $627.

- Track the reference period, BRL scope and actual spending; the village assumes 36 homes.



**Presenter notes:** Rafael explicitly cited SindusCon/CUB and SINAPI in November 2025. On 30 November he provided a $21,883.86 construction calculation plus land, then an optimized $27,777 budget with direct procurement and shared costs. The five lines total $27,777. He specified 36 homes, $999,972 and a 12-month program. Present this engineering basis rather than an unexplained number. Preserve scope and current execution records. A blanket 15% CUB deduction is not an independently proved saving: the reference scope matters. The January two-loft contract is $27,777 combined and is a separate case.



## 4. One accountable organization coordinates the home.

Property control, resident agreements and builder responsibilities must connect in writing.



- Document ownership or operating authority for the selected property.

- Contract the builder and disclose related-party terms.

- Specify what the resident pays, earns toward ownership and receives at completion.



**Presenter notes:** A proposed donation or memorandum is not a completed property transfer. A token is not the title record. The legal form and transfer arrangement need Brazilian professional review.



## 5. Keep each source and use visible.

Rent, grants, service receipts and trading fees enter the books separately.



- Pay taxes, collection and agreed property/organization costs.

- Fund repairs, resident commitments, vacancies and reserves.

- Commit growth capital under an agreed rule; assess any lawful surplus afterward.



**Presenter notes:** Historical 98% rental distributions are not adopted here. Resident purchase credits are obligations or entitlements, not extra cash. A resale payment belongs to the seller except for separately collected fees. Locked trading liquidity is not available construction cash.



## 6. Self-sufficiency has two tests.

Cover the homes already operating. Then finance the next cohort.



- Test full operating costs through low or zero trading activity.

- Account for rent ending when a home transfers to its resident.

- Identify retained assets or recurring services; model expansion capital separately.



**Presenter notes:** One thousand homes is a hypothesis, not a break-even result. Grants may help eligible costs but one-off awards are not recurring income. Three- or six-year reviews do not guarantee a distribution.



## 7. A voice comes from a role, not just a balance.

Consult on resident authority, delegated work and separately defined financial rights.



- Resident voice on shared use and maintenance within agreed limits.

- Time-limited delivery roles, conflict checks and replaceable representatives.

- Occupancy and purchase rights stay protected by agreements and law.



**Presenter notes:** One token, one vote on everything risks purchased control. The consultation example uses equal voice per verified member in resident matters, relevant experience for elected/appointed work roles, and financial-holder rights defined by their instrument. It is not an adopted charter. Ostrom informs boundaries, local fit, collective choice, accountable monitoring, proportionate responses, conflicts, recognized authority and nested levels. See roadmap.html#governance. Online activity or a score does not decide housing rights.



## 8. Make fair cooperation the simplest path.

SIAH Protocol is the brand. Hive DAO names the decentralized operating rails.



- Shared context, voluntary roles and succession help work continue.

- Ostrom-informed rules; Python agents; Arc settlement; possible Arctide fees.

- The Flock supplies Telegram access; IMOBX would test the complete loop.



**Presenter notes:** Hive DAO describes the operating model, not a separate evidence service. Participants should be able to identify a need, take responsibility within agreed roles and budgets, obtain required authorization, check delivery and payment, and pass context to a successor. SIAH Protocol is the brand. Agents help maintain context and permissions around treasuries, identities and wallets. Resident rights and financial-holder rights stay distinct. Demonstrate coordination, challenges and handover without constant founder instructions. Complete IMOBX operation remains to be verified; the engineering follows separate authorized work. The Flock remains neutral and reusable across projects. Arc is the settlement network; Arctide is a candidate fee source, with Argus and Uniswap alternatives requiring their own integration proof.



## 9. Separate participation from financial entitlement.

A mission-led nonprofit operator and an investor dividend need distinct legal consideration.



- Choose the legal form and protect restricted donations and resident commitments.

- Define any financial claim, issuer, cash source and permitted offer/transfer route.

- Reinvestment may grow operations; it is not automatic token yield or appreciation.



**Presenter notes:** Under Law 13.019's nonprofit definition for public-sector partnerships, results support the social purpose rather than distributions. Do not promise the nonprofit's profits as investor dividends. Consider participation without profit rights or a separately permitted financial arrangement with Brazilian advisers; no structure is adopted. A DAO/governance label does not settle securities treatment. No supply, APY, sale date or tenant allocation is agreed.



## 10. Evidence gates, with parallel work streams.

The distinct roadmap links housing delivery, governance and useful digital services.



- Days 1–30: roles, entity/property evidence, scoped budget and consultation.

- Days 31–60: cash rules and decision exercises; day 90: readiness decision.

- Funded pilot → operating evidence → token decision and repeatable delivery.



**Presenter notes:** Proposed preparation targets start only from an agreed date; construction needs funding, property and permits. Observe at least three operating months before the first replication review. Website v1 is published; operational v2 reports real delivery/cash and does not require a token. Optional v3 token access follows rights, legal/provider and technical verification. See roadmap.html and faq.html. A second local team must repeat the process; one thousand homes does not prove self-sufficiency.



## 11. Count homes and fulfilled commitments.

The first scorecard measures delivery, cash discipline and resident experience.



- Budget and schedule variance; property rights and resident agreement.

- Monthly source/use/reserve reconciliation; maintenance and unresolved issues.

- Resident participation and progress under the ownership agreement.



**Presenter notes:** Set numeric service targets after the pilot baseline. No invented beneficiaries, capital commitments or completed transfers are shown. Trading volume and holder count are financial market observations, not housing impact.



## 12. Help define and verify the first pilot.

The next ask is practical expertise and a bounded delivery arrangement.



- Property and building partners: confirm scope, access, costs and delivery.

- Housing, accounting and legal partners: review rights, reserves and funding route.

- Resident/community partners: test the agreement, information and support process.



**Presenter notes:** Agree the specific scope, responsible people, deliverables and decision dates with each partner. No funding amount or token purchase is requested by this draft. Read the companion whitepaper for assumptions, sources and unresolved decisions.



## Sources

- [Project facts and cost provenance](whitepaper.html#3-the-cost-proposal-already-supplied)

- [Arctide technical documentation](https://github.com/0xRustyDev/arctide-docs/blob/main/README.md)

- [CVM Guidance Opinion 40](https://conteudo.cvm.gov.br/legislacao/pareceres-orientacao/pare040.html)

- [Ostrom Nobel lecture](https://www.nobelprize.org/prizes/economic-sciences/2009/ostrom/lecture/)

- [IBGE: favelas and urban communities](https://www.ibge.gov.br/geociencias/organizacao-do-territorio/tipologias-do-territorio/15788-favelas-ecomunidades-urbanas.html?edicao=38944&t=o-que-e)

- [IBGE: 2022 Census context](https://agenciadenoticias.ibge.gov.br/agencia-noticias/2012-agencia-de-noticias/noticias/41797-censo-2022-brasil-tinha-16-4-milhoes-de-pessoas-morando-em-favelas-e-comunidades-urbanas)

- [UN-Habitat: adequate housing](https://unhabitat.org/11-1-adequate-housing)

- [IMOBX roadmap and consultation charter](https://siah-kin.github.io/imobx-website/roadmap.html)

- [IMOBX model FAQ](https://siah-kin.github.io/imobx-website/faq.html)

- [ICA cooperative identity](https://ica.coop/en/cooperatives/cooperative-identity)

- [Law 13.019 article 2](https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2014/lei/l13019compilado.htm)
