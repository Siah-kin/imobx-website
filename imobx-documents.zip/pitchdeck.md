# IMOBX

A documented rent-to-own housing model for Rio

**Partner discussion draft · Version 0.9, 9 November 2026**



## 1. Families would rent toward owning their home

IMOBX is preparing a first rent-to-own housing project in Rio.



- Local construction and clear family agreements.

- Residents help shape shared spaces and decisions.

- Current stage: planning, documents and design.



Source: [IMOBX resources and sources](https://imobx.org/resources.html#sources). Lists what exists and what is not decided, with a review date. It is the project's own record.

**Presenter notes:** Rafael brings construction and local experience; John handles community and digital work. Their roles, the legal organization and the right to use each property need written agreements. This draft explains the plan and asks for partners; it does not offer an investment.



## 2. Start with what a family needs

The first project would help families who rent today and cannot get ordinary housing finance.



- Agree who can join and what payments are affordable.

- Explain repairs, payments and the path to buying the home.

- Make help and complaints easy to access.



Source: [UN-Habitat: adequate housing](https://unhabitat.org/11-1-adequate-housing). Describes what adequate housing means. It does not assess IMOBX.

**Presenter notes:** Brazil’s 2022 Census counted about 16.4 million residents in favelas and urban communities, 8.1% of the population. That is national context, not a description of a selected family or site. Living in a favela does not itself mean being displaced. Listen to families about work, schools, transport, support networks and whether a move suits them. Participating households are not identified in this draft.



## 3. Rafael has worked out what one flat costs

His sum starts from CUB, the public Rio building-cost index: about R$180,000 for a 45 m² flat with its share of the land.



- Building R$150,400 (R$111,400 from CUB plus 35% for overheads and margin) · land up to R$30,000.

- Five flats at a time on one plot, bought whole for about R$140,000.

- First new flat, with the whole plot, about R$290,000; five new flats about R$892,000.



Source: [Whitepaper, section 3: the costs](whitepaper.html#3-the-cost-proposal-already-supplied). Shows how Rafael supplied these figures.

**Presenter notes:** In September 2026 Rafael worked out the cost of a 45 m² flat: 45 × R$2,476 (CUB-RJ) = about R$111,400, plus 35% for overheads and margin = R$150,400, plus land of up to R$30,000. The CUB rate for a small building may be higher. The plot for five flats is bought whole, for about R$140,000. A village of about 36 houses is a later stage and has no budget yet. These are Rafael’s figures, not an index-published finished-flat price. Track dates, included work, prices in reais and actual invoices.



## 4. Part of each payment would go towards buying the home

The household could see what it has paid towards the purchase and how much remains.



- The agreement sets the price and how much of each payment goes towards buying.

- The household can follow the amount paid and the remaining price.

- The whole house transfers to the household once the purchase terms are met.



**Presenter notes:** The first family would most likely live in the Guadalupe building that Olympus built; the new flats are still being planned. The price for each family and its monthly payment are not decided yet; both are agreed with the family in writing. How much of each payment would count towards buying it also remains to be agreed. Rafael’s cost sum and the two-loft contract are construction cases, not household sale prices. Repair charges, hardship and exit terms remain open. The household explanation is at rent-to-own.html. Before building, the project needs documents showing the right to use the property, a budget and someone independent to inspect the work.



## 5. Show where each payment goes

Keep rent, donations, grants, service income and trading fees separately identified.



- Pay taxes, repairs and agreed running costs.

- Keep funding for empty houses and promises made to families.

- Fund more houses under the agreed budget.



**Presenter notes:** Funding credited toward a family’s purchase is not a second receipt of cash. A buyer’s payment for the token goes into the trading pool; only the fee on each trade is shared out. Funding locked in a trading market is not also available to build houses.



## 6. Pay today’s bills and plan the next houses

Running the existing houses and building more need separate budgets.



- Check the budget with little or no trading income.

- Rent ends when the family becomes the home’s owner.

- Show how continuing income and new building funds will be found.



**Presenter notes:** Having a thousand houses does not itself show that the accounts balance. One-off grants can help construction but do not become continuing income. Any ongoing charge needs a real, affordable service under agreed terms.



## 7. Residents would decide how shared spaces are used

Courtyard use, study-room hours, repair priorities and representatives are resident matters.



- One member, one vote, as Brazil’s cooperative law sets out.

- No investment purchase or promotional work would be required for a voice.

- Investor rights and each household’s contract have their own terms.



Source: [ICA: cooperative identity](https://ica.coop/en/cooperatives/cooperative-identity). States the principles of cooperatives, including member participation. It does not review IMOBX.

Source: [Elinor Ostrom: Nobel lecture](https://www.nobelprize.org/prizes/economic-sciences/2009/ostrom/lecture/). Is research on how communities manage shared resources. It does not test IMOBX's rules.

**Presenter notes:** The voting procedure, spending limits and way to question a decision have not been agreed with participants. In the proposed repair process, a resident reports a leak, a maintenance contact obtains a quote, spending follows the agreed limit and another person checks the work. Whatever a token vote decides, only the family and IMOBX together, under the law, can change a family’s housing agreement. See rent-to-own.html#decisions and governance.html.



## 8. From a request to checked work

Agreed roles, spending limits and shared records keep everyday work moving.



- A resident raises an issue; a responsible person takes it forward.

- Someone else checks the work, payment and receipt.

- Open tasks and approvals are ready for whoever takes over.



**Presenter notes:** Before the pilot, residents and the organization need to agree which matters each group decides, spending limits and how a decision can be reviewed. For example: a resident reports a leak, the maintenance role assesses it and obtains a quote, spending follows the agreed rule, and another person checks the repair and payment. Routine work should proceed within those limits without constant founder instructions. Residents need ways to choose and replace responsible people. The support channel would show requests, decisions and progress; software assistants could organize documents and reminders. Blockchain could show payment amounts and destinations. These tools follow the rules agreed by participants. The complete process still needs to be demonstrated in IMOBX.



## 9. Every trade of the token pays a fee that funds the community

Holding the token is optional, and families join IMOBX as members. It is a planned self-compounding community-funding token with no presale.



- Each trade would pay a fee: 14% on Arctide, plus its own 0.25%, and 11% on Argus.

- Each fee would go 45% to wages and 35% to the trading pool; the 20% for people who lock tokens waits for a lawyer’s reading.

- Its use comes from four rules: Volume, Verify, Vote and Vow.



Source: [CVM Guidance Opinion 40](https://conteudo.cvm.gov.br/legislacao/pareceres-orientacao/pare040.html). Says Brazil's regulator looks at what an investment actually gives, not its name.

Source: [IMOBX: the Self-compounding page](https://imobx.org/token.html). Sets out the token’s fee, where it goes and the four V’s as the project describes them.

**Presenter notes:** The first house is funded outside the token: once the IMOBX housing cooperative is registered, it will run a crowdfunding campaign in reais and apply for grants. The campaign runs before the token launches, its backers receive ordinary rewards and never tokens, and the two are always presented separately. The fee would add to the houses budget over time. Buyers’ payments would go into the trading pool, so none of them would reach IMOBX. In the founders’ model, 20% of each fee would go to people who lock their tokens for good; that share waits for a lawyer’s reading. When IMOBX puts in the pool’s starting funds, it would hold three quarters of the pool, so three quarters of the 35% would go to new houses; if the token opens with a sale on Arctide’s bonding curve, that part would go to Arctide. Volume: the fees would give the community an income of its own. Verify: anyone could check where each fee went and who approved it. Vote: on the token’s own rules, weight would come mainly from work others have confirmed; members’ decisions stay one member, one vote. Vow: the commitments no vote can break, starting with each family’s housing agreement. Benefits for holders are chosen later from what IMOBX can actually supply. We start building a house only when its funding is secured.



## 10. Each stage needs evidence before it advances

The roadmap names proposed roles and conditions for proceeding.



- Property rights, household terms and budgets underpin the first houses.

- Digital payment trials would run alongside them; the token is a separate, later step.

- Expansion follows operating results and funding for existing commitments.



Source: [IMOBX project stages](https://imobx.org/roadmap.html). Sets out the stages and what must be ready in each. It sets no dates.

**Presenter notes:** The six stages are legal structure and property; resident participation; first houses; payment records people can check; funding and account review; more houses and owner partnerships. Rafael contributes construction and local knowledge; John contributes communication and digital coordination. Olympus is Rafael’s own construction company and the proposed builder. Its appointment would need approval by someone independent of the builder. A community or charitable partner is a possible relationship. Construction dates depend on the chosen project, funding and permissions. A review after at least three operating months is proposed before expanding. The roadmap lists responsibilities and reasons to pause each stage.



## 11. Measure houses and promises kept

Follow actual costs, accounts and families’ experience.



- Check completed work, final cost and delays.

- Check funding received and paid against the records; report repairs and unresolved issues.

- Show participation and progress toward owning the home.



**Presenter notes:** Agree response times and affordability targets with local participants. Report houses as planned, contracted, delivered or transferred, with checked records. Token prices and holder counts do not measure how well families are housed.



## 12. One property can become a project to assess

An owner, building team, local organization and funder could develop a costed proposal together.



- Owners: property, condition and donation, sale or lease terms.

- Builders and funders: costed work, funding purpose and commitments.

- Households: affordable terms, location, repairs and resident decisions.



**Presenter notes:** These are possible contributions, not confirmed partnerships or contracts. The contact page has separate routes and explanations. The contact page has an email address (contact@imobx.org) and a way to prepare an introduction first; the website sends nothing by itself. You can also join the IMOBX group on Telegram, where the co-founders reply. A property introduction can lead to assessment, not an automatic transfer. If a builder is connected to an IMOBX founder, someone independent must check the contract and completed work. See contact.html and rent-to-own.html#property.


