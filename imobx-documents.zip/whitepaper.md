# IMOBX

## A documented rent-to-own housing model for Rio

**Project paper v0.2 · 16 October 2026 · Project proposal**

IMOBX wants to help families rent a home and follow a clear path to buying it. We are preparing a first housing project in Rio de Janeiro. The plan brings together local building work, written agreements, maintenance and accounts people can check.

Rafael brings construction experience and knowledge of local conditions. John works on community communication and digital tools. Their responsibilities and IMOBX’s legal form still need to be agreed in writing.

We want each family to understand what it pays, what counts toward buying the home and who handles repairs. Supporters should be able to see where their money goes. IMOBX needs enough money to meet these commitments before starting more homes.

This paper explains the plan and the decisions still needed. It does not establish donated properties, a token sale or a right to investment income.

## 1. Who the pilot is for

The first project would serve families who have been displaced or cannot use ordinary housing finance. With local participants, we need to agree who can join, what they can afford and which locations meet their needs. A move must make sense for the family’s work, school, transport and support network.

Housing problems exist worldwide. In Brazil, favelas and urban communities have their own histories, businesses and relationships. Brazil’s 2022 Census counted around 16.4 million residents in these areas, 8.1% of the population. That national figure does not tell us the condition of a particular home or family. Living in a favela does not itself mean someone is displaced. [IBGE terminology](https://www.ibge.gov.br/geociencias/organizacao-do-territorio/tipologias-do-territorio/15788-favelas-ecomunidades-urbanas.html?edicao=38944&t=o-que-e); [2022 Census](https://agenciadenoticias.ibge.gov.br/agencia-noticias/2012-agencia-de-noticias/noticias/41797-censo-2022-brasil-tinha-16-4-milhoes-de-pessoas-morando-em-favelas-e-comunidades-urbanas); [UN-Habitat](https://unhabitat.org/11-1-adequate-housing).

Before anyone joins, the agreement must explain payments, the purchase price, repairs, late payments, hardship, leaving the program and what happens if IMOBX cannot continue. Families need a practical way to get help and challenge a decision.

<div class="pagebreak"></div>

## 2. The housing and delivery arrangement

IMOBX would own each included property or have a written legal right to operate it. It would sign agreements with families and hire builders and other providers. Each property needs a file showing its owner, debts or restrictions, permissions, condition, building plan, budget and responsible people.

A property might be donated, leased, sold or made available under another agreement. Its agreement needs to identify which arrangement applies. A letter saying someone intends to donate is different from a completed transfer. Ownership needs the required property registration.

July’s discussions considered a foreign organization holding Brazilian property. Receita Federal confirms that such an organization needs a CNPJ, Brazil’s business tax registration. Registration, property ownership and acceptance by a bank or exchange are separate matters. IMOBX’s chosen legal form and any received properties still need documents. [Receita Federal](https://www.gov.br/receitafederal/pt-br/assuntos/orientacao-tributaria/cadastros/cnpj/solicitacao-de-atos-perante-o-cnpj-por-meio-da-internet/orientacoes-para-pessoa-juridica-domiciliada-no-exterior).

Rafael’s building company is a possible contractor. Its catalogue can show experience when completed work and permission to publish it are checked. A founder linked to a builder should not approve that builder’s own bill: price, profit, changes and delivery need checks by someone else.

### Rafael's village vision, 30 November 2025

Rafael proposed 45 m² two-level homes facing a shared courtyard, with solar panels, fruit trees, play space and two study rooms. The aim is a path to ownership, lower household costs and places to meet and learn. The [illustration](properties.html#visao-rafael) shows this vision, not a completed village.

Residents would help agree who cares for shared spaces, how study rooms are used and how repairs are paid for. Solar savings need real equipment and usage figures; some electricity charges remain. [ANEEL guidance](https://www.gov.br/aneel/pt-br/assuntos/geracao-distribuida/).

<div class="pagebreak"></div>

## 3. The cost proposal already supplied

Rafael prepared a **US$27,777 budget per 45 m² home** using CUB and SINAPI, Brazilian building-cost references, and his purchasing and construction plan. On 30 November 2025, he showed a US$21,883.86 construction calculation plus US$5,550 for land. He then supplied this revised budget:

| Item | Rafael’s budget, USD per home |
|---|---:|
| Land | 5,550 |
| House construction, 45 square metres | 18,600 |
| Solar | 1,500 |
| Shared infrastructure and facilities | 1,500 |
| Legal and design | 627 |
| **Total** | **27,777** |

His plan calls for at least 36 homes built together: **US$999,972 over 12 months**. Buying directly and sharing building work and facilities are part of the savings plan. Each actual build must record its price date, quantities, included work, costs in reais and invoices.

These are Rafael’s project figures, not a finished-home price published by a cost index. CUB leaves out some site works, connections, design and builder payments. A saving must be explained through the work and purchasing plan; deducting a presumed profit percentage does not prove it. [SINAPI](https://www.caixa.gov.br/poder-publico/modernizacao-gestao/sinapi/paginas/default.aspx); [CUB scope](https://sinduscon-caxias.net.br/servicos/cub).

### The separate two-loft case

On 20 January 2026, Rafael reported a signed contract for two lofts on a steep site, waiting for the first deposit. The owner clarified that **US$27,777 covers both lofts together**: US$13,888.50 each by division. We still need the included work, current progress and final costs. This is separate from the village budget. [Drawings and photos](properties.html#estudo-lofts).

The first project’s payment amount and purchase term remain to be agreed. Each family’s agreement needs affordable payments in reais and clear rules for price changes.

<div class="pagebreak"></div>

## 4. How the money would work

The proposed financial plan covers homes and continued service. Payment and reinvestment rules remain to be agreed.

The proposed accounts would identify each payer, purpose and permitted use, with separate records for rent, donations, grants, investments, service income and trading fees. If someone buys a token from another holder, the sale money normally goes to the seller. Only a separately collected project fee goes to IMOBX.

The proposed order is:

1. Record the money actually received.
2. Set aside taxes and amounts promised for a specific purpose.
3. Pay agreed property, maintenance and administration bills.
4. Keep money for repairs, empty homes, resident commitments and unexpected costs.
5. Fund new homes under the agreed budget.
6. Consider investor payments only if money remains and a valid agreement allows them.

Payments credited toward a family’s purchase are a commitment under its agreement. They are not a second receipt of cash. Using the money elsewhere must not make the promised home transfer impossible. Money locked in a trading market also cannot pay a building bill at the same time.

## 5. Trade fees as supplementary funding

An optional source of funding is a fee collected when people buy or sell a future token. IMOBX would need an agreement stating which fees it receives, what they may pay for and how receipts are checked. A sale between two holders normally pays the seller; it does not provide a new building budget for IMOBX.

These receipts could help fund agreed work without creating more IMOBX tokens for that payment. They still depend on trading. Test the plan with little or no trading income; higher fees may discourage buyers and sellers.

The construction budget needs committed funding. A token’s market value does not establish money available to pay building bills.

<div class="pagebreak"></div>

## 6. What self-sufficiency means

IMOBX would support its existing operation when recurring income covers its regular bills, repairs and commitments to families. Building more homes needs additional money. These are two separate tests.

When a family becomes the owner, IMOBX stops receiving rent from that home. Forecasts must show how income continues afterward. Any ongoing service charge needs a real service, an affordable price and terms the resident agreed to.

A one-off grant can help build, but it is not continuing income. Having 1,000 homes does not by itself show that the accounts balance. We need to follow groups of homes from building through payments to ownership.

## 7. Resident voice and accountable governance

We are developing a DAO: an organization where people share decisions and use software to help follow the agreed rules. Residents, property contributors, builders, staff, donors, possible investors, neighbours and independent checkers need clear roles. We have mapped their likely needs for discussion, not confirmed them through interviews.

Ostrom studied how people manage shared resources. We want to apply useful lessons: define the group, involve affected people, check work and spending, resolve disputes and keep local decisions close to residents. [Ostrom’s lecture](https://www.nobelprize.org/prizes/economic-sciences/2009/ostrom/lecture/).

| Who or what | Proposed rule to discuss |
|---|---|
| Families | Affordable payments, repairs and a written path to owning the whole home. |
| Property contributors | Clear donation, sale or lease terms and responsibility for debts and transfer costs. |
| Builders and suppliers | Agreed work, price, payment dates and independent delivery checks. |
| Staff and resident representatives | Clear powers, spending limits, appointment, reporting and replacement. |
| Donors and social funders | Agreed use of funds and evidence of housing results. |
| Possible investors | Written claims, costs, losses, decision rights and exit terms. |
| Neighbours | A voice on local impacts, services and access. |
| Independent checkers | Access and authority to review property, safety, accounts and agreements. |

One option is equal member voice in resident matters and elected people responsible for work. Experience can help choose someone for a time-limited role; online activity need not become votes. Newcomers need a way to participate. A family’s housing and purchase agreement cannot be rewritten by a token vote alone. No resident token plan is agreed. [Cooperative principles](https://ica.coop/en/cooperatives/cooperative-identity); [decision examples](roadmap.html#governance).

<div class="pagebreak"></div>

## 8. What a token could represent

We are studying a token as a financial tool to raise capital for building homes and growing the housing operation. In a new issue, investors would pay the issuing organization for defined financial rights. The token could record those rights and help manage payments and permitted transfers. We still need to choose the legal structure, investor rights and income source. Fundraising could precede construction once the organization, property authority, budget and permitted offer are ready; future rent is a forecast, not money already received.

We want each family to be able to own its **whole home**. Sharing purchasing and administration across projects could save work. The proposal does not split every house between token buyers. A future investment linked to IMOBX or several projects would need to state which properties, debts, income and shared risks it includes.

The nonprofit idea is intended to keep money serving housing. Its legal form remains undecided. Law 13.019, covering public-sector partnerships, defines nonprofits that use their results for their social purpose. We cannot simply promise those results as investor dividends. Brazilian advisers need to review participation without profit rights and any other permitted investment arrangement. A donation given for building homes must keep its agreed purpose. [Law 13.019, article 2(I)(a)](https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2014/lei/l13019compilado.htm).

A membership record and an investment do different jobs. A membership record does not itself give property ownership or rental income. If an investment is offered, its agreement must say who owes what, who may buy, how payments work and how someone may sell or leave. Brazilian CVM guidance looks at actual rights, not just names such as “utility” or “governance.” [CVM Guidance Opinion 40](https://conteudo.cvm.gov.br/legislacao/pareceres-orientacao/pare040.html).

We have not set token supply, resident allocation, returns, lock-up periods, fees or a sale date. This paper claims no SEC or MiCA approval. The first housing project can proceed with ordinary agreements if a token adds no useful benefit.

<div class="pagebreak"></div>

## 9. What becomes digital

We want people to follow money in and out, see agreed decisions and check payments. Blockchain could provide a shared payment record. It does not check the quality of a roof or replace the family’s agreement.

For the first project, compare a shared digital record with ordinary accounts and signed agreements: what gets easier to check, how much does it cost, who can correct an error and who keeps access? A token cannot create rental income, verify a building or guarantee a buyer when someone wants to leave. [OECD study](https://www.oecd.org/content/dam/oecd/en/publications/reports/2021/11/understanding-the-tokenisation-of-assets-in-financial-markets_2e657111/c033401a-en.pdf).

Residents and the organization would agree who decides each matter, spending limits and how a decision can be reviewed. Everyday work should follow these rules without waiting for instructions from the founder.

For example, a resident reports a leak through the support channel. The person handling maintenance assesses it, gets a quote and follows the agreed spending rule. Someone else checks the repair. The payment and receipt go into the accounts. Residents can raise a problem and ask for review.

Tasks need a responsible person, deadline and budget. If someone leaves a role, their replacement should find the open work, approvals and documents needed to continue. Residents need ways to choose and replace responsible people. Personal information stays private.

Software assistants could organize documents and remind people about unfinished work. Blockchain records could show payment amounts and destinations. The agreed rules still determine who may decide or spend. This method needs agreement with participants and a working pilot. [Daily decisions and tasks](faq.html#faq-flock-siah).

Families would pay in reais. IMOBX would keep money for Brazilian bills and use digital payments only for an agreed purpose. Any conversion needs an accepted provider, a full cost record and a tested route back to the bank. No provider is confirmed for IMOBX. Residents would not need crypto wallets. [Money path](transparency.html#settlement); [payment-service requirements](transparency.html#ramp-options).

<div class="pagebreak"></div>

## 10. Pilot roadmap and evidence

The [roadmap](roadmap.html) proposes the first 30 days for roles, property, budget and family discussions; days 31–60 for money and decision rules; and a decision by day 90 on whether the project is ready. Dates start when agreed. Building also needs property, money and permissions.

After families move in, follow at least three months before reviewing expansion. A second local team should be able to repeat the work. The website can report real progress and accounts before any token exists. A later purchase screen would follow agreed rights and a checked legal and payment route.

| What to follow | What to show |
|---|---|
| Homes and agreements | Written property authority and a signed family agreement before moving in. |
| Building | What was delivered, actual cost and any delay. |
| Money | Monthly checks of every receipt, payment and amount set aside. |
| Families | Repair requests, unresolved issues, participation and purchase progress. |
| Continuing the project | Bills covered during low trading and funding for the next homes. |

Agree service targets once the first project’s needs are understood. Token prices and holder counts do not measure how well a family is housed.

## 11. Partner participation

We need practical help: confirm property access, update building and repair budgets, review family agreements and make accounts easy to follow. Families should help shape the service before rules are fixed. This paper asks for expertise and a clear first project, not token purchases.

## 12. Risks, decisions and evidence register

Rafael supplied the November budget and January two-loft account. Their dates and different purposes matter. Designs show intended buildings, not completed homes. No number of donated properties or received funding is confirmed here.

The legal registration, property documents, permissions and signed agreements need checking for the chosen project. The researched payment services do not establish a working IMOBX connection. Resident voting, reinvestment and token rights remain decisions to agree.

Planned project updates would show agreements signed, funding received and work completed, alongside open questions and the people responsible for answering them.
