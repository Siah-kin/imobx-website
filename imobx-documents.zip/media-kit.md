# IMOBX media kit

**Version 0.2 · 16 October 2026 · Project in preparation**

Use this kit for IMOBX logos, colours and short project descriptions. IMOBX is preparing a rent-to-own housing project in Rio. The paper and pilot guide explain the plan and the decisions still needed.

## 1. Logo files

Use the existing logo without redrawing, stretching or changing its colours. Leave clear space around it. Use the white-background version on the website and documents.

- [Light logo, PNG](assets/imobx-logo-light.png).
- [Dark logo, JPG](assets/imobx-logo-dark.jpg).
- [Original light artwork, WebP](assets/imobx-logo-light-source.webp).

The PNG is ready for websites and PDFs. The original WebP is included too. No editable vector logo is supplied.

## 2. Colours and type

The [visual identity guide](media-kit.html#brand-guide) describes the logo, colours and where the images came from and what was changed. [Text version](DESIGN.md).

| Use | Colour |
|---|---|
| Page background | #FFFFFF |
| Pale background | #F7FAFB |
| Borders | #D9E3E8 |
| Main text | #193D4E |
| Secondary text | #526571 |
| Teal accent | #4A90A4 |
| Occasional orange accent | #FF8C00 |
| Pale print panel | #E8F4F8 |

Use readable type such as Arial. Keep backgrounds white and corners square. Explain an idea before a diagram. Leave room around text and use orange sparingly. Check that text is easy to read against its background.

[Download colours, JSON](brand-colors.json).

## 3. Short description in English

IMOBX is preparing a first housing project in Rio de Janeiro. Families would rent a home under a clear agreement explaining how they can become its owner. Local builders, residents and supporters would help make the project work. Shared decisions and digital tools for following work and funding are being developed. IMOBX’s legal form, the terms for using each property and any token rights are still being decided.

## 4. Descrição curta em português

A IMOBX está preparando um primeiro projeto de moradia no Rio de Janeiro. As famílias alugariam uma casa com um contrato claro explicando como podem se tornar donas dela. Construtores locais, moradores e apoiadores ajudariam a fazer o projeto funcionar. Estão sendo desenvolvidas decisões compartilhadas e ferramentas digitais para acompanhar trabalho e recursos. A forma jurídica, as condições de uso de cada imóvel e os direitos de um eventual token ainda estão em definição.

### Rafael's neighbourhood vision

On 30 November 2025, Rafael described two-level houses around a shared courtyard, with solar panels, fruit trees, play space and two study rooms. These features aim to support lower household costs, neighbourly life and learning. The [illustration](properties.html#visao-rafael) shows a plan, not a completed village. The January two-loft contract is a separate case. Costs, maintenance arrangements and any claimed savings need evidence from the chosen project.

## 5. Project facts and images

IMOBX is in preparation. Its legal form, the terms for using each property and any token rights remain undecided. No investment, guaranteed return, funding award or regulatory approval is established by these documents.

Rafael’s US$27,777 per-home village budget uses CUB/SINAPI building-cost references and shared costs across at least 36 houses. The [project paper](whitepaper.html#3-the-cost-proposal-already-supplied) provides the dates and breakdown.

The city photographs show favelas along the hillsides, highlighted by circles. The collection also includes construction photographs, loft drawings and the village concept. [View the photographs and drawings](properties.html).

## 6. Project resources

- [Whitepaper](whitepaper.html): houses, funding, shared decisions and sources.
- [Pitch deck](pitchdeck.html): twelve slides for partners.
- [Pilot and building guide](devsheet.html): housing plans, responsibilities and proposed targets.
- [Roadmap](roadmap.html): steps and what must be ready before moving on.
- [Questions about funding, tokens and governance](transparency.html#funding-questions): plain explanations of the model and digital tools.
- [Questions families ask](rent-to-own.html#questions): renting, buying, repairs, decisions and taking part.
- [All documents](resources.html): online reading and downloads.

<div id="7-brand-provenance"></div>

## 7. Logo sources

The supplied logo files are available in this kit and in the [project repository](https://github.com/Siah-kin/imobx-website). The website and documents use white backgrounds, the light logo and the palette above.
