# IMOBX visual identity and images

**Brand reference · 16 October 2026**

IMOBX’s visual identity uses its supplied house-shaped logo, white space and a restrained teal palette. The website presents the housing proposal alongside local photographs and architectural drawings.

## Logo

The supplied logo combines a house symbol with the IMOBX name. Its colours, proportions and lettering form one piece of artwork. Clear space around it keeps it legible.

- [Logo for light backgrounds, PNG](assets/imobx-logo-light.png)
- [Logo for dark backgrounds, JPG](assets/imobx-logo-dark.jpg)
- [Original light artwork, WebP](assets/imobx-logo-light-source.webp)

The website and documents use the light version on white. No editable vector artwork is included.

## Colours and type

| Use | Colour |
|---|---|
| White background | #FFFFFF |
| Pale background | #F7FAFB |
| Main text | #193D4E |
| Secondary text | #526571 |
| Teal accent | #4A90A4 |
| Borders | #D9E3E8 |
| Occasional orange accent | #FF8C00 |

The publication uses readable sans-serif type, simple headings and generous space around text and photographs. [Colour definitions](brand-colors.json).

<div id="documentary-editorial-approach"></div>

## Photographs and drawings

The city photographs show favelas along the hillsides. Circles highlight the favelas in each view.

The village drawing is Rafael’s design for the village, not a listing of houses for rent. The loft drawings show proposed designs, and construction photographs show the site and building work.

## Project descriptions

The [media kit](media-kit.html) provides short descriptions in Portuguese and English. The [project paper](whitepaper.html) explains the housing proposal, costs and current stage. These descriptions identify the project as being in preparation. IMOBX will be a housing cooperative and is not registered yet, and token rights are still being decided.

## Resources

- [Media kit and logo downloads](media-kit.html)
- [Photos and drawings](properties.html)
- [Project documents](resources.html)
